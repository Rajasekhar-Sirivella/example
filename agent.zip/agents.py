from crewai import Agent
from tools import tool
from dotenv import load_dotenv
load_dotenv()
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_groq import ChatGroq
import os

## Uncomment to use Gemini model
'''llm = ChatGoogleGenerativeAI(
    model="google/gemini-1.5-flash",
    provider="google",  
    verbose=True,
    temperature=0.4,
    max_tokens=None,
    google_api_key=os.getenv("GEMINI_API_KEY")
)
'''
## Using ChatGroq with the `gemma2-9b-it` model
llm = ChatGroq(
    model='groq/llama-3.2-3b-preview',
    provider='groq',
    temperature=0.4,
    verbose=True,
    api_key=os.getenv("GROQ_API_KEY"),
    max_tokens=None,  # No limit on token usage
    max_retries=3     # Retry up to 3 times on errors
)

# Creating a senior researcher agent with memory and verbose mode
product_researcher = Agent(
    role="Product Researcher",
    goal='Uncover missing values in {topic}',
    verbose=True,
    memory=True,
    backstory=(
        "With a sharp analytical mind, you specialize in analyzing inputs to identify and fill gaps, "
        "ensuring comprehensive and accurate outcomes that drive meaningful insights."
    ),
    tools=[tool],
    llm=llm,
    allow_delegation=True
)

# Creating a writer agent responsible for writing news blogs
data_updater = Agent(
    role='Data Updater',
    goal='Transform the refined data into a well-structured CSV format for seamless utilization.',
    verbose=True,
    memory=True,
    backstory=(
        "Meticulous and detail-oriented, you excel at organizing refined data into structured formats. "
        "Your work ensures data is accessible, reliable, and ready for analysis or further use."
    ),
    tools=[tool],
    llm=llm,
    allow_delegation=False
)


