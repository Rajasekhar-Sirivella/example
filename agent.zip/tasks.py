from crewai import Task
from tools import tool
from agents import product_researcher,data_updater

# Research task
research_task = Task(
  description=(
    "Analyze the provided data on {topic} to identify missing values and inconsistencies. "
    "Focus on ensuring the dataset is complete, accurate, and ready for further analysis. "
    "Your final output should contain the filled-in values and a summary of changes made."
  ),
  expected_output='A refined dataset with missing values filled and a summary of modifications made.',
  tools=[tool],
  agent=product_researcher,
)


# Writing task with language model configuration
write_task = Task(
  description=(
    "After filling in the missing values, convert the refined data into a CSV file. "
    "Ensure the data is structured appropriately for future use and analysis. "
    "Provide the CSV file along with a brief summary of the dataset's structure."
  ),
  expected_output='A CSV file containing the updated data and a brief summary of its structure.',
  tools=[tool],
  agent=data_updater,
  async_execution=False,
  output_file='updated_data.csv'  # Example of output customization
)
