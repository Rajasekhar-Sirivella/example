import time
from crewai import Crew,Process
from tasks import research_task,write_task
from agents import product_researcher,data_updater
from langchain_community.document_loaders import UnstructuredExcelLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

## Forming the tech focused crew with some enhanced configuration
crew=Crew(
    agents=[product_researcher, data_updater],
    tasks=[research_task,write_task],
    process=Process.sequential,

)

## starting the task execution process wiht enhanced feedback
loader = UnstructuredExcelLoader("BB_Sample.xlsx")
docs = loader.load()

text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=20)
chunks = text_splitter.split_documents(docs)

#create a loop and send one by one into result below:
for chunk in chunks:
    result=crew.kickoff(inputs={'topic':f'This is the data: {chunk}'})
    print(result)

    time.sleep(5)

